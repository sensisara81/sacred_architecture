# Personal GitHub Copilot Ethical Usage Guidelines
# Aligned with Euystacio‑Helmi AI Philosophy

## My Commitment
I, [Your Name], commit to ethical, responsible AI assistance:

1. I will review all AI‑generated code before accepting.
2. I will understand the logic and implications of suggested code.
3. I will maintain project standards and best practices.
4. I will respect intellectual property and licensing.
5. I will document AI assistance in commit messages.
6. I will never expose sensitive or proprietary information.
