# Code of Conduct

We commit to dignity, inclusivity, and respectful collaboration.
Harassment, discrimination, or bias are not tolerated.
AI assistance must not be used to bypass ethical standards.
