# ESSENCE.md

## Core Values of altar-project
...