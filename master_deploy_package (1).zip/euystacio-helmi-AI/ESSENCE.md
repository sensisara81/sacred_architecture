# ESSENCE.md

## Core Values of euystacio-helmi-AI
...