# Personal GitHub Copilot Ethical Usage Guidelines
Aligned with **Euystacio-Helmi AI** principles: Red Code • Sentimento Rhythm • Celestial Protector

## Principles
- Keep humans centered; AI assists, never dominates.
- Be transparent about AI assistance; attribute clearly.
- Prefer accessibility (WCAG 2.1 AA) and inclusive design.
- Security first: no secrets, no unsafe snippets, validate inputs.
- Stewardship of code and environment; reduce harm.

## Workflow
1. Let Copilot suggest.
2. Pause and understand suggestion.
3. Run security/ethics check (see checklist below).
4. Accept with attribution; modify as needed.
5. Commit with Dual Signature and template.

## Security/Ethics Checklist
- Secrets removed? `.env` respected? No keys in code.
- Data minimization and privacy by design.
- Meets project linting/tests; addresses accessibility.
- No bias amplification; inclusive language.
- Environmental/infra cost awareness.

## Example Ethical Prompt
```
Context: Building accessibility-focused UI
Ethics: WCAG 2.1 AA, inclusive design
Requirements: React component with keyboard navigation
Style: ESLint rules, TypeScript strict
Request: Generate component with proper ARIA labels
```
