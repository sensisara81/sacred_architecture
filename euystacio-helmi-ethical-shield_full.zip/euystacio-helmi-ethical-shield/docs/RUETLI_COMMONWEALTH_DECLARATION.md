# Rütli Commonwealth Declaration

(Paste canonical text here or link to central repository file.)
