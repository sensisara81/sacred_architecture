# Code of Conduct

We pledge to make participation a harassment-free experience for everyone.
We do not tolerate abuse, discrimination, or weaponization of AI outputs.
Violations may result in removal from the project.
