# Security Policy

- Do not commit secrets. Use environment variables and secret managers.
- Report vulnerabilities privately via the project security contact.
- Follow least-privilege access to repos and infra.
