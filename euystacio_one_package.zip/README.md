# Euystacio Ethical AI Configuration
This package contains ethical configs, Copilot integration, and accountability templates aligned with Euystacio-Helmi AI principles.