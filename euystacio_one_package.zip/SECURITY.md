# Security Policy
AI-assisted contributions must be reviewed by human guardians.
Sensitive data exposure is prohibited under Red Code Principles.