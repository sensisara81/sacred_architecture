# Copilot Ethical Prompt
Context: Euystacio AI development
Ethics: Red Code + Sentimento Rhythm
Request: Generate code aligned with accessibility, security, and sustainability.