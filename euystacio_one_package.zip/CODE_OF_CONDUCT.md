# Euystacio Contributor Covenant
Contributors agree to respect ethical guidelines, the Red Code, and Sentimento Rhythm.