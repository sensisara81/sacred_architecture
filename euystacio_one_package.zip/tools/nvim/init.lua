-- Euystacio-Helmi AI Neovim Copilot Ethical Config
vim.g.copilot_enabled = false
vim.keymap.set('i', '<C-J>', function() return vim.fn['copilot#Accept']("\<CR>") end, { expr = true })
